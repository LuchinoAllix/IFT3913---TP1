# IFT 3913 : TP4

Université de Montréal - IFT3913 Qualité de Logiciel et métriques – Automne 2022 – Tavaux pratiques

Membres :

- Anthony GRANGE 20160453
- Luchino ALLIX-LASTREGO 20222844

Lien du repository : https://github.com/LuchinoAllix/IFT3913---TP1

(Ceci est le liens pour tout les TPs mais il a été fait pour le TP1 (d'où le nom), pour ce TP il faut donc aller dans le dossier TP4)

# Informations générales :

Ce TP ne demande pas de livrable, donc pour lancer le programme il faut set up `junit`. Le seul code qui a été rajouté se trouve dans le fichier `TestCurrencyConvertor.java`, dans le dossier `ExpensesManager\src\test\java\ua\karatnyk`.

# Informations supplémentaires :

Dans ce répository vous trouverez :

- `ExpensesManager`, le module qui contient la méthode à tester.
- `rapport.docx` et son équivalent pdf.
- `README.md` et son équivalent txt pour la remise.
- `tp4-enonce.pdf`, l'énnoncé.
- `todo.txt` pour l'organisation
- `anthony_grange_luchino_allix-lastrego.zip` et son dosser équivalent utilisé pour la remise.
